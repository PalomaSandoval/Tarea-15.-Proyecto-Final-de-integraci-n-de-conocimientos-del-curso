<?php
 //Paloma Ivonne Sandoval Granados 368027
 //Mauricio Antonio Balderrama Chaparro 367582
//Resultados

if (isset($_POST['temperatura']) && isset($_POST['unidad'])) {

    $temperatura = $_POST['temperatura'];
    $unidad = $_POST['unidad'];

    if (!is_numeric($temperatura)) {
        header("Location: Tarea5.php?error=1");
        exit();
    }

    $temperatura = floatval($temperatura);

    if ($unidad == "Celsius") {
        $resultado = ($temperatura * 9/5) + 32;
        $mostrarTemperatura = "$temperatura °C = $resultado °F";
    } else {
        $resultado = ($temperatura - 32) * 5/9;
        $mostrarTemperatura = "$temperatura °F = $resultado °C";
    }

} else {
    header("Location: Tarea5.php?error=1");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Resultado</title>
    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f7f7f7d7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        h2 {
            color: #333333;
            font-size: 1.6rem;
            margin-bottom: 20px;
            text-align: center;
        }

        p {
            background-color: #ffffff;
            padding: 20px 25px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            font-size: 1.2rem;
            text-align: center;
            color: #222222;
            min-width: 280px;
        }
    </style>
</head>
<body>
    <div>
        <h2>Resultado de la conversión</h2>
        <p>
            <?php echo $mostrarTemperatura; ?>
        </p>
    </div>
</body>
</html>
