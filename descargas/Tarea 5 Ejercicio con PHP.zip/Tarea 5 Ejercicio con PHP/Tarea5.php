<?php
 //Paloma Ivonne Sandoval Granados 368027
 //Mauricio Antonoio Balderrama Chaparro 367582
 //Formulario
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Transformar temperaturas</title>
    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f7f7f7d7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .form-container {
            background-color: #ffffff;
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            width: 320px;
            text-align: center;
        }

        h2 {
            margin-bottom: 20px;
            color: #333333;
            font-size: 1.6rem;
        }

        label {
            display: block;
            text-align: left;
            margin-bottom: 8px;
            color: #555555;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px 12px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 1rem;
        }

        input[type="radio"] {
            margin-right: 6px;
            margin-left: 6px;
        }

        input[type="submit"] {
            background-color: #2098a8ff;
            color: white;
            border: none;
            padding: 10px 18px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #211468ff;
        }

        /* Mensaje de error */
        .form-container p {
            margin-top: 15px;
            color: #d93025;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Transformar temperaturas</h2>
        <form action="Tarea5_resultado.php" method="post">
            <label for="temperatura">Introduce la temperatura:</label>
            <input type="text" name="temperatura" placeholder=" " required /><br>
            <input type="radio" name="unidad" value="Celsius" required /> Celsius
            <input type="radio" name="unidad" value="Fahrenheit" required /> Fahrenheit
            <input type="submit" value="Transformar" />
        </form>

        <?php
            if (isset($_GET["error"])) {
                echo "<p>Solo puedes agregar numeros, no letras</p>";
            }
        ?>
    </div>
</body>
</html>
