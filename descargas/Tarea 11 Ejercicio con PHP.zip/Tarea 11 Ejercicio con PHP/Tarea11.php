<?php

/* Paloma Ivonne Sandoval Granados 
    Mauricio Antonio Balderrama Chaparro
    Tarea 11
*/


if (isset($_COOKIE['colorCookie'])) {
    header('Location: resultado.php');
    exit; 
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Formulario de Colores</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            display: grid;
            place-items: center;
            min-height: 100vh;
            margin: 0;
        }
        .formulario-card {
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            padding: 2rem 3rem;
            text-align: center;
        }
        select, button {
            font-size: 1rem;
            padding: 8px 12px;
            margin-top: 10px;
        }
        button {
            background-color: #4CAF50; 
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

    <div class="formulario-card">
        <h2>Bienvenido al formulario de colores de la Tarea 11</h2>
        
        <form action="resultado.php" method="POST">
            <label for="color">Selecciona el color:</label>
            <select name="colorSeleccionado" id="color">
                <option value="Rojo">Rojo</option>
                <option value="Azul">Azul</option>
                <option value="Verde">Verde</option>
                <option value="Amarillo">Amarillo</option>
            </select>
            
            <br><br>
            
            <button type="submit">Elegir</button>
        </form>
    </div>

</body>
</html>