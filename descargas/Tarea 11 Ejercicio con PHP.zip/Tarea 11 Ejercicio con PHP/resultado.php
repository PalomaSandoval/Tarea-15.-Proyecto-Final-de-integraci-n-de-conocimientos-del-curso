<?php
/* Paloma Ivonne Sandoval Granados 
    Mauricio Antonio Balderrama Chaparro
    Tarea 11
*/

$color_seleccionado = '';

if (isset($_POST['colorSeleccionado'])) {
    $color_seleccionado = $_POST['colorSeleccionado'];

    setcookie('colorCookie', $color_seleccionado, time() + (3 * 60));
} 
else if (isset($_COOKIE['colorCookie'])) {
    $color_seleccionado = $_COOKIE['colorCookie'];
} 
else {
    echo "No hay cookie";
}

switch ($color_seleccionado) {
    case 'Rojo':
        $color_css = 'red';
        break;
    case 'Azul':
        $color_css = 'blue';
        break;
    case 'Verde':
        $color_css = 'green';
        break;
    case 'Amarillo':
        $color_css = 'orange'; 
        break;
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Resultado Colores</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            display: grid;
            place-items: center;
            min-height: 100vh;
            margin: 0;
        }
        .formularioc {
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            padding: 2rem 3rem;
            text-align: center;
        }
        .mensaje-color {
            font-size: 1.5rem;
            font-weight: bold;
            color: <?php echo $color_css; ?>;
        }
    </style>
</head>
<body>

    <div class="formularioc">
        <h2>Color seleccionado</h2>
        
        <p class="mensaje-color">
            Texto del color <?php echo $color_seleccionado; ?>
        </p>
        
        <br>
        <a href="Tarea11.php">Volver al formulario</a>
    </div>

</body>
</html>