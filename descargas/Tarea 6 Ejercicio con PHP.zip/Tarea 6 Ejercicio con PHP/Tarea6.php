<?php
 //Paloma Ivonne Sandoval Granados 368027
 //Mauricio Antonoio Balderrama Chaparro 367582
 //Formulario
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 40px;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        form {
            background: #fff;
            padding: 20px 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        label {
            font-weight: bold;
            margin-right: 10px;
        }

        input[type="number"] {
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-right: 10px;
            width: 100px;
        }

        input[type="submit"] {
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            background-color: #007BFF;
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        table {
            border-collapse: collapse;
            width: 60%;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0px 4px 12px rgba(0,0,0,0.1);
        }

        th {
            background: #007BFF;
            color: white;
            padding: 12px;
            text-align: center;
        }

        td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        tr:nth-child(even) {
            background: #f9f9f9;
        }

        tr:hover {
            background: #e9f3ff;
        }
    </style>

    <title>Tarea 6</title>
</head>
<body>
    <h2>Crear tabla</h2>
    <form action="Tarea6_Resultado.php" method="post">
        <label>Introduce el número de filas: </label>
        <input type="number" name="numero" required>
        <input type="submit" value="Crear">
    </form>
</body>
</html>
