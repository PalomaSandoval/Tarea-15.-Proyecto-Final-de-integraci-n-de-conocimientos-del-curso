<?php
 //Paloma Ivonne Sandoval Granados 368027
 //Mauricio Antonoio Balderrama Chaparro 367582
 //Resultados
?>

<!DOCTYPE html>
<html>
<head>
    <title>Resultado de las tablas</title>
</head>
<style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 40px;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        form {
            background: #fff;
            padding: 20px 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        label {
            font-weight: bold;
            margin-right: 10px;
        }

        input[type="number"] {
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-right: 10px;
            width: 100px;
        }

        input[type="submit"] {
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            background-color: #007BFF;
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        table {
            border-collapse: collapse;
            width: 60%;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0px 4px 12px rgba(0,0,0,0.1);
        }

        th {
            background: #007BFF;
            color: white;
            padding: 12px;
            text-align: center;
        }

        td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        tr:nth-child(even) {
            background: #f9f9f9;
        }

        tr:hover {
            background: #e9f3ff;
        }
    </style>

<body>
    <?php
    if (isset($_POST['numero'])) {
        $n = (int) $_POST['numero'];

        echo "<h2>Tabla con $n filas</h2>";

        echo "<table border='1'>";
        echo "<tr>
                <th>Columna 1</th>
                <th>Columna 2</th>
                <th>Columna 3</th>
              </tr>";

        for ($i = 1; $i <= $n; $i++) {
            echo "<tr>";
            echo "<td>Fila $i, Celda 1</td>";
            echo "<td>Fila $i, Celda 2</td>";
            echo "<td>Fila $i, Celda 3</td>";
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "<p>No se recibió ningún número.</p>";
    }
    ?>
</body>
</html>
